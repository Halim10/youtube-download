﻿namespace YoutubeDownloader.Models
{
    public enum QueryKind
    {
        Video,
        Playlist,
        Channel,
        Search
    }
}