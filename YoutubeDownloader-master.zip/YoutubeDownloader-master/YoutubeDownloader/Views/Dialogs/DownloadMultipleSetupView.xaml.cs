﻿namespace YoutubeDownloader.Views.Dialogs
{
    public partial class DownloadMultipleSetupView
    {
        public DownloadMultipleSetupView()
        {
            InitializeComponent();
        }
    }
}